import PyColors.RgbColors as rgbcolors

color = rgbcolors.Color()
print(color.red)